"""
Blueprints package
Contiene todos los blueprints modulares de la aplicación
"""
